<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>
    <style type="text/css">
        body {margin: 0;  padding: 0; width: 100%;}
    </style>
</head>
<body>

<div style="display: block;  width: 100%; overflow:hidden; padding-bottom: 10px">
    <div  style="width: 33%; float: left; text-align: left;  font-size: 12px; color:#032b79;">
        <span>PASEO DE LA BOQUITA#43, LOCAL 2, ESQ. CALLE GEMA</span>
        <span>ZIHUATANEJO, GRO. TEL (755) 125-8576</span>
    </div>

    <div style="width: 50%; float: left; text-align: center; font-size: 12px; color:#032b79;">
        <span>www.puertoverde.net</span><br>
        <span>ventas@puertoverde.net</span>
    </div>

    <div style="width: 17%; float: right; text-align: right; font-size: 12px;color:#032b79;">
        <span>TELF: (755) 125-8576</span>
    </div>
</div>


</body>
</html>
<?php /**PATH /home/karel/www/puertoverde/resources/views/footer.blade.php ENDPATH**/ ?>