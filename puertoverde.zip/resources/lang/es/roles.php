<?php

return [
    'owner' => 'Dueño',
    'admin' => 'Administrador',
    'sales_team_lead' => 'Lider de equipo',
    'sales_agent' => 'Agente de venta',
    'editor' => 'Editor',
    'customer_service' => 'Servicio al cliente',
];
