<?php

return [
    'password' => 'La contraseña debe ser de al menos 6 caracteres y coincidir con la confirmación.',
    'reset' => '¡Tu contraseña ha sido actualizada!',
    'sent' => '¡Te hemos enviado un correo electrónico para que puedas actualizar tu contraseña!',
    'token' => 'El token para actualizar tu contraseña es inválido.',
    'user' => 'No existe ningún usuario con el correo electrónico proporcionado..',
];
