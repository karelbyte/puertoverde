<?php

return [

    "addresses"=> "Direcciones",

    "assets"=> "Activos",

    "blog"=> "Blog",

    "brands"=> "Marcas",

    "code_snippets"=> "Fragmentos de código",

    "contacts"=> "Contactos",

    "coupons"=> "Cupones",

    "dashboards"=> "Cuadros de mando",

    "domains"=> "Dominios",

    "funnels"=> "Enbudos",

    "gateways"=> "Pasarelas",

    "integrations"=> "Integrasiones",

    "metadata"=> "Metadatos",

    "notes"=> "Notas",

    "offers"=> "Offertas",

    "opportunities"=> "Oportunidades",

    "orders"=> "Ordenes",

    "phones"=> "Telefonos",

    "pixels"=> "Pixels",

    "plans"=> "Planes",

    "products"=> "Productos",

    "roles"=> "Roles",

    "shop"=> "Tienda",

    "subscriptions"=> "Suscripciones",

    "tags"=> "Etiquetas",

    "teams"=> "Equipos"

];
