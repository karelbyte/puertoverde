<?php

return [
    'main' => 'Main',
    'index' => 'Listado',
    'create' => 'Crear',
    'update' => 'Editar',
    'delete' => 'Eliminar',
    'show' => 'Vista',
];
