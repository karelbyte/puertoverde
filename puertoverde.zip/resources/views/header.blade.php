<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>
    <style type="text/css">
        body {margin: 0;  padding: 0; width: 100%;}
    </style>
</head>
<body>

<img src="{{asset('asset/pv.png')}}" alt="">

</body>
</html>
